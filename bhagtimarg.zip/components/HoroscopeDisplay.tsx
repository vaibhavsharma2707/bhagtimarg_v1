import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ZODIAC_SIGNS } from '../constants';
import { getDailyHoroscope } from '../utils/horoscopeData';
import Spinner from './Spinner';

interface HoroscopeDisplayProps {
    signId: string;
}

const HoroscopeDisplay: React.FC<HoroscopeDisplayProps> = ({ signId }) => {
    const { language } = useLanguage();
    const [prediction, setPrediction] = useState<{ en: string; hi: string } | null>(null);
    const [loading, setLoading] = useState(true);

    const sign = ZODIAC_SIGNS.find(s => s.id === signId);

    useEffect(() => {
        setLoading(true);
        const timer = setTimeout(() => {
            setPrediction(getDailyHoroscope(signId));
            setLoading(false);
        }, 300); // Simulate a quick data fetch
        return () => clearTimeout(timer);
    }, [signId]);

    if (!sign) return null;

    return (
        <div className="bg-brand-bg p-8 rounded-xl shadow-lg animate-fade-in">
            {loading ? (
                <div className="flex justify-center items-center h-48">
                    <Spinner />
                </div>
            ) : (
                <div className="flex flex-col sm:flex-row items-center text-center sm:text-left">
                    <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-8">
                        <div className="p-4 bg-amber-100 rounded-lg shadow-inner">
                            <img src={sign.imageUrl} alt={sign.name.en} className="w-24 h-24 mx-auto" />
                        </div>
                    </div>
                    <div>
                        <h2 className="text-4xl font-bold font-serif text-brand-secondary">
                            {language === 'en' ? sign.name.en : sign.name.hi}
                        </h2>
                        <p className="text-brand-accent text-lg mb-4">{sign.dateRange}</p>
                        <p className="text-brand-text text-xl leading-relaxed font-serif">
                            {prediction ? (language === 'en' ? prediction.en : prediction.hi) : ''}
                        </p>
                    </div>
                </div>
            )}
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default HoroscopeDisplay;