import React from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { ALL_CONTENT } from '../data/content';
import { useLanguage } from '../contexts/LanguageContext';
import AudioPlayer from '../components/AudioPlayer';
//import MusicPlayer from '../components/MusicPlayer';

const ContentDisplayPage: React.FC = () => {
  const { contentId } = useParams<{ contentType: string, contentId: string }>();
  const { language } = useLanguage();
  const contentItem = ALL_CONTENT.find(c => c.id === contentId);

  if (!contentItem) {
    return <Navigate to="/" />;
  }

  const goBackLink = contentItem.deityId ? `/deity/${contentItem.deityId}` : '/';

  const contentToDisplay = (language === 'hi' && contentItem.content_hi) 
    ? contentItem.content_hi 
    : contentItem.content;

  return (
    <div className="max-w-3xl mx-auto bg-brand-bg p-8 md:p-12 rounded-xl shadow-lg">
       <Link to={goBackLink} className="text-brand-primary hover:text-brand-secondary mb-6 inline-block font-semibold">&larr; {language === 'en' ? 'Back' : 'वापस'}</Link>
      
      {contentItem.audioUrl && (
        <div className="mb-8">
          <AudioPlayer src={contentItem.audioUrl} title={language === 'en' ? contentItem.title : contentItem.title_hi} />
        </div>
      )}

      <h1 className="text-4xl md:text-5xl font-bold font-serif text-center text-brand-secondary mb-2">
        {language === 'en' ? contentItem.title : contentItem.title_hi}
      </h1>
      <h2 className="text-3xl md:text-4xl font-serif text-center text-brand-accent mb-8">
        {language === 'en' ? contentItem.title_hi : contentItem.title}
      </h2>
      <div className="space-y-4 text-center text-lg md:text-xl font-serif text-brand-text leading-loose">
        {contentToDisplay.map((line, index) => (
          <p key={index}>{line}</p>
        ))}
      </div>
    </div>
  );
};

export default ContentDisplayPage;