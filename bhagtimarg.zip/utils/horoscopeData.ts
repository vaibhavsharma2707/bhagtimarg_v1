// This utility provides procedurally generated, dynamic daily horoscopes.

const predictions = {
    en: [
        "Today is a day for new beginnings. Embrace the change and watch as new opportunities unfold before you.",
        "Your financial prospects are looking bright. An unexpected gain might be on the horizon. Stay alert.",
        "Communication is key today. A meaningful conversation could resolve a long-standing issue.",
        "Focus on your health and well-being. A little self-care will go a long way in boosting your energy.",
        "Creative energies are high. It's a perfect day to indulge in your artistic hobbies and express yourself.",
        "A challenge at work may test your patience, but your perseverance will lead to a rewarding outcome.",
        "Your relationships will be a source of great joy today. Spend quality time with loved ones.",
        "An opportunity for travel or learning could present itself. Be open to expanding your horizons.",
        "Listen to your intuition today; it will guide you in making an important decision.",
        "Teamwork will bring success. Collaborate with your peers to achieve a common goal.",
        "It's a good day for reflection and planning for the future. Set your intentions clearly.",
        "Patience is a virtue today. Avoid rushing into decisions and let things unfold naturally."
    ],
    hi: [
        "आज नई शुरुआत का दिन है। बदलाव को अपनाएं और देखें कि कैसे आपके सामने नए अवसर खुलते हैं।",
        "आपकी वित्तीय संभावनाएं उज्ज्वल दिख रही हैं। एक अप्रत्याशित लाभ हो सकता है। सतर्क रहें।",
        "आज संचार महत्वपूर्ण है। एक सार्थक बातचीत लंबे समय से चले आ रहे मुद्दे को हल कर सकती है।",
        "अपने स्वास्थ्य और कल्याण पर ध्यान दें। थोड़ी सी आत्म-देखभाल आपकी ऊर्जा को बढ़ाने में बहुत मदद करेगी।",
        "रचनात्मक ऊर्जा उच्च है। अपनी कलात्मक रुचियों में शामिल होने और खुद को व्यक्त करने के लिए यह एक आदर्श दिन है।",
        "कार्यस्थल पर एक चुनौती आपके धैर्य की परीक्षा ले सकती है, लेकिन आपकी दृढ़ता एक पुरस्कृत परिणाम की ओर ले जाएगी।",
        "आज आपके रिश्ते बड़ी खुशी का स्रोत होंगे। प्रियजनों के साथ गुणवत्तापूर्ण समय बिताएं।",
        "यात्रा या सीखने का अवसर मिल सकता है। अपनी क्षितिज का विस्तार करने के लिए खुले रहें।",
        "आज अपनी अंतर्ज्ञान की सुनें; यह आपको एक महत्वपूर्ण निर्णय लेने में मार्गदर्शन करेगा।",
        "टीम वर्क सफलता लाएगा। एक सामान्य लक्ष्य प्राप्त करने के लिए अपने साथियों के साथ सहयोग करें।",
        "यह भविष्य के लिए चिंतन और योजना बनाने के लिए एक अच्छा दिन है। अपने इरादे स्पष्ट रूप से निर्धारित करें।",
        "आज धैर्य एक गुण है। निर्णयों में जल्दबाजी करने से बचें और चीजों को स्वाभाविक रूप से सामने आने दें।"
    ]
};

// Simple pseudo-random number generator that is deterministic based on date and sign
function getDeterministicRandom(seed: number): number {
    let x = Math.sin(seed) * 10000;
    return x - Math.floor(x);
}

export function getDailyHoroscope(signId: string): { en: string, hi: string } {
    const today = new Date();
    const day = today.getDate();
    const month = today.getMonth();
    const year = today.getFullYear();

    // Create a unique seed for today and the specific sign
    // The signId is converted to a number by summing its character codes
    const signSeed = signId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const seed = day + month * 31 + year * 365 + signSeed;

    const randomIndex = Math.floor(getDeterministicRandom(seed) * predictions.en.length);

    return {
        en: predictions.en[randomIndex],
        hi: predictions.hi[randomIndex]
    };
}